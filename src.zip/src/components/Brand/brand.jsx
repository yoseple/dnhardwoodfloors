import React from 'react'

const brand = () => {
  return (
    <div>brand</div>
  )
}

export default brand