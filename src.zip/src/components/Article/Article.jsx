import React from 'react'

const Article = () => {
  return (
    <div>Article</div>
  )
}

export default Article