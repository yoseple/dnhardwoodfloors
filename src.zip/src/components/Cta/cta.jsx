import React from 'react'

const cta = () => {
  return (
    <div>cta</div>
  )
}

export default cta