import React from 'react'

const possibility = () => {
  return (
    <div>possibility</div>
  )
}

export default possibility