import React from 'react'

const header = () => {
  return (
    <div>header</div>
  )
}

export default header