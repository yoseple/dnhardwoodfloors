import React from 'react'

const features = () => {
  return (
    <div>features</div>
  )
}

export default features