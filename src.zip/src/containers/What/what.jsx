import React from 'react'

const what = () => {
  return (
    <div>what</div>
  )
}

export default what